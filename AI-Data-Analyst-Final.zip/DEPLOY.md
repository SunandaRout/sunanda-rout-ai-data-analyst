# GitHub + Vercel Deployment

## 1. GitHub
Create a new GitHub repository, then upload/extract all files from this folder into the repository root.

Or from a terminal inside the project:

```bash
git init
git add .
git commit -m "Initial AI Data Analyst"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## 2. Vercel
1. Sign in to Vercel.
2. Add/import the GitHub repository.
3. Framework should be detected as Next.js.
4. Build command: `next build` (or leave the default).
5. Deploy.

## 3. OpenAI key
In Vercel Project Settings → Environment Variables, add:

`OPENAI_API_KEY` = your OpenAI API key

Optional:

`OPENAI_MODEL` = `gpt-5-mini`

Redeploy after adding variables.

## 4. Local testing
```bash
npm install
copy .env.example .env.local
npm run dev
```

Never commit `.env.local` or an API key. `.gitignore` already excludes `.env.local`.

## Important
The app's initial CSV profiling happens in the browser. The AI endpoints receive the generated dataset summary rather than the complete CSV contents.
