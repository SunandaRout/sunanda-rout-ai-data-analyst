# AI Data Analyst

A portfolio-ready AI-powered data analytics web application built with Next.js.

## What it does
Upload a CSV dataset and get:
- Automatic dataset profiling
- Missing-value and data-quality checks
- Numeric/categorical field detection
- Interactive visualizations
- Pearson correlation analysis
- CSV export
- Natural-language AI questions
- AI-generated executive report

## Tech
Next.js • React • JavaScript • Papa Parse • Recharts • OpenAI API

## Run
```bash
npm install
```

Create `.env.local`:
```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5-mini
```

Then:
```bash
npm run dev
```

Open `http://localhost:3000`.

## Deploy
See `DEPLOY.md` for GitHub + Vercel deployment instructions.

## Portfolio
Suggested project title:

**AI Data Analyst — Intelligent CSV Analytics Platform**

Suggested description:

> Built an AI-powered analytics platform that profiles CSV datasets, performs data-quality checks, visualizes patterns, calculates correlations, answers natural-language questions, and generates executive reports.

## Security
Do not put API keys in client-side code or commit them to GitHub. Use environment variables.
