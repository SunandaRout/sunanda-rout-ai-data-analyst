import OpenAI from "openai";

export async function POST(req) {
  try {
    const { question, summary } = await req.json();
    if (!process.env.OPENAI_API_KEY) {
      return Response.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: [
        {
          role: "system",
          content: "You are an expert data analyst. Answer using only the supplied dataset summary. Be concise, practical, and clearly state when the summary is insufficient."
        },
        {
          role: "user",
          content: `Dataset summary:\n${JSON.stringify(summary, null, 2)}\n\nQuestion: ${question}`
        }
      ]
    });

    return Response.json({ answer: response.output_text });
  } catch (error) {
    return Response.json({ error: error?.message || "AI request failed." }, { status: 500 });
  }
}