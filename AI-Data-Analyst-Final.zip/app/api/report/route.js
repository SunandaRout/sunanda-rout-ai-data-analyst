import OpenAI from "openai";

export async function POST(req) {
  try {
    const { summary } = await req.json();
    if (!process.env.OPENAI_API_KEY) return Response.json({error:"OPENAI_API_KEY is not configured."},{status:500});
    const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const r = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      input: `You are a senior data analyst. Create a concise executive data report with these headings:
Executive Summary
Data Quality
Key Findings
Recommended Next Steps
Use only this dataset profile and do not invent exact facts:
${JSON.stringify(summary,null,2)}`
    });
    return Response.json({report:r.output_text});
  } catch(e) {
    return Response.json({error:e?.message||"Report generation failed."},{status:500});
  }
}