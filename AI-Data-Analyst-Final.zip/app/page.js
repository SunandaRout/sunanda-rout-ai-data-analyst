"use client";

import { useMemo, useState } from "react";
import Papa from "papaparse";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from "recharts";

function analyze(rows) {
  if (!rows.length) return null;
  const columns = Object.keys(rows[0]);
  const stats = columns.map((name) => {
    const values = rows.map(r => r[name]).filter(v => v !== "" && v != null);
    const nums = values.map(Number).filter(v => Number.isFinite(v));
    const missing = rows.length - values.length;
    const unique = new Set(values.map(String)).size;
    const avg = nums.length ? nums.reduce((a,b)=>a+b,0)/nums.length : null;
    return { name, type: nums.length >= Math.max(3, values.length * 0.7) ? "numeric" : "categorical",
      missing, unique, min: nums.length ? Math.min(...nums) : null,
      max: nums.length ? Math.max(...nums) : null, avg };
  });
  const numeric = stats.filter(s => s.type === "numeric");
  const categorical = stats.filter(s => s.type === "categorical");
  return { rows: rows.length, columns, stats, numeric, categorical };
}

function chartData(rows, column, type) {
  if (type === "numeric") {
    return rows.map((r, i) => ({ index: i + 1, value: Number(r[column]) }))
      .filter(x => Number.isFinite(x.value)).slice(0, 100);
  }
  const counts = {};
  rows.forEach(r => {
    const v = String(r[column] ?? "").trim() || "Missing";
    counts[v] = (counts[v] || 0) + 1;
  });
  return Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0, 10)
    .map(([name, value]) => ({ name, value }));
}


function correlation(rows, a, b) {
  const pairs = rows.map(r => [Number(r[a]), Number(r[b])])
    .filter(([x,y]) => Number.isFinite(x) && Number.isFinite(y));
  if (pairs.length < 3) return null;
  const ax = pairs.map(p=>p[0]), by = pairs.map(p=>p[1]);
  const mx = ax.reduce((a,b)=>a+b,0)/ax.length, my = by.reduce((a,b)=>a+b,0)/by.length;
  const num = pairs.reduce((t,[x,y])=>t+(x-mx)*(y-my),0);
  const den = Math.sqrt(pairs.reduce((t,[x])=>t+(x-mx)**2,0) * pairs.reduce((t,[,y])=>t+(y-my)**2,0));
  return den ? num/den : null;
}

function downloadCSV(rows) {
  const cols = Object.keys(rows[0] || {});
  const esc = v => `"${String(v ?? "").replaceAll('"','""')}"`;
  const csv = [cols.map(esc).join(","), ...rows.map(r=>cols.map(c=>esc(r[c])).join(","))].join("\\n");
  const blob = new Blob([csv], {type:"text/csv"});
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download="cleaned_dataset.csv"; a.click();
}

export default function Home() {
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [selected, setSelected] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [reportLoading, setReportLoading] = useState(false);
  const [report, setReport] = useState("");
  const [corrA, setCorrA] = useState("");
  const [corrB, setCorrB] = useState("");

  const analysis = useMemo(() => analyze(rows), [rows]);

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    Papa.parse(file, {
      header: true, skipEmptyLines: true,
      complete: ({ data }) => {
        setRows(data);
        setSelected("");
        setAnswer("");
      }
    });
  }

  async function askAI() {
    if (!question || !analysis) return;
    setLoading(true);
    setAnswer("");
    try {
      const res = await fetch("/api/ask", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({
          question,
          summary: {
            fileName, rows: analysis.rows, columns: analysis.columns,
            stats: analysis.stats
          }
        })
      });
      const data = await res.json();
      setAnswer(data.answer || data.error || "No answer returned.");
    } catch {
      setAnswer("Could not reach the AI service. Add OPENAI_API_KEY to .env.local and restart the app.");
    } finally {
      setLoading(false);
    }
  }

  const numeric = analysis?.numeric?.[0];
  const categorical = analysis?.categorical?.[0];
  const currentColumn = selected || numeric?.name || categorical?.name;
  const currentType = analysis?.stats.find(s => s.name === currentColumn)?.type;
  const data = analysis ? chartData(rows, currentColumn, currentType) : [];

  return (
    <main className="page">
      <header className="hero">
        <div>
          <div className="eyebrow">PERSONAL AI PRODUCT</div>
          <h1>AI Data Analyst</h1>
          <p>Upload a CSV. Discover patterns, visualize data, and ask questions in natural language.</p>
        </div>
        <div className="badge">v1.0 MVP</div>
      </header>

      <section className="upload card">
        <div className="upload-icon">↥</div>
        <div>
          <h2>{fileName || "Upload your CSV dataset"}</h2>
          <p>Start with any clean CSV file. Your browser parses the dataset for instant analysis.</p>
        </div>
        <label className="button">
          Choose CSV
          <input type="file" accept=".csv,text/csv" onChange={handleFile} hidden />
        </label>
      </section>

      {!analysis ? (
        <section className="empty card">
          <div className="big">📊</div>
          <h2>Your analytics workspace is ready</h2>
          <p>Try a dataset such as sales, customers, hotel bookings, or shopping behaviour.</p>
        </section>
      ) : (
        <>
          <section className="metrics">
            <Metric label="Rows" value={analysis.rows.toLocaleString()} />
            <Metric label="Columns" value={analysis.columns.length} />
            <Metric label="Numeric fields" value={analysis.numeric.length} />
            <Metric label="Categorical fields" value={analysis.categorical.length} />
          </section>

          <section className="grid">
            <div className="card">
              <div className="section-head">
                <div><h2>Data overview</h2><p>Automatic field profiling</p></div>
              </div>
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Column</th><th>Type</th><th>Missing</th><th>Unique</th><th>Average</th></tr></thead>
                  <tbody>{analysis.stats.map(s => (
                    <tr key={s.name}>
                      <td>{s.name}</td><td><span className="pill">{s.type}</span></td>
                      <td>{s.missing}</td><td>{s.unique}</td>
                      <td>{s.avg == null ? "—" : s.avg.toFixed(2)}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </div>

            <div className="card chart-card">
              <div className="section-head">
                <div><h2>Visualization</h2><p>Choose a field</p></div>
                <select value={currentColumn || ""} onChange={e=>setSelected(e.target.value)}>
                  {analysis.columns.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="chart">
                <ResponsiveContainer width="100%" height="100%">
                  {currentType === "numeric" ? (
                    <LineChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="index" /><YAxis /><Tooltip /><Line type="monotone" dataKey="value" strokeWidth={2} dot={false}/></LineChart>
                  ) : (
                    <BarChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" angle={-25} textAnchor="end" height={70}/><YAxis /><Tooltip /><Bar dataKey="value" radius={[6,6,0,0]} /></BarChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>
          </section>


          <section className="advanced-grid">
            <div className="card advanced-card">
              <div className="section-head">
                <div><div className="ai-label">DATA QUALITY</div><h2>Cleaning assistant</h2><p>Quick checks before analysis.</p></div>
              </div>
              <div className="quality-list">
                {analysis.stats.filter(s=>s.missing>0).length === 0
                  ? <div className="good">✓ No missing values detected</div>
                  : analysis.stats.filter(s=>s.missing>0).map(x=><div className="quality-row" key={x.name}><span>{x.name}</span><b>{x.missing} missing</b></div>)}
              </div>
              <button className="button small" onClick={()=>downloadCSV(rows)}>Export CSV</button>
            </div>

            <div className="card advanced-card">
              <div className="section-head">
                <div><div className="ai-label">CORRELATION</div><h2>Compare numeric fields</h2><p>Measure linear relationship.</p></div>
              </div>
              <div className="corr-row">
                <select value={corrA} onChange={e=>setCorrA(e.target.value)}>
                  <option value="">Field A</option>{analysis.numeric.map(x=><option key={x.name}>{x.name}</option>)}
                </select>
                <select value={corrB} onChange={e=>setCorrB(e.target.value)}>
                  <option value="">Field B</option>{analysis.numeric.map(x=><option key={x.name}>{x.name}</option>)}
                </select>
              </div>
              {corrA && corrB && corrA !== corrB && <div className="corr-result">{(correlation(rows,corrA,corrB) ?? 0).toFixed(3)}<span> Pearson correlation</span></div>}
            </div>
          </section>

          <section className="card report-card">
            <div className="section-head">
              <div><div className="ai-label">AI REPORT</div><h2>Generate executive report</h2><p>Create a concise analyst-style summary from the dataset profile.</p></div>
              <button className="button small" disabled={reportLoading} onClick={async()=>{
                setReportLoading(true); setReport("");
                try {
                  const res = await fetch("/api/report",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
                    summary:{fileName,rows:analysis.rows,columns:analysis.columns,stats:analysis.stats}
                  })});
                  const d=await res.json(); setReport(d.report||d.error||"No report returned.");
                } catch { setReport("Could not generate the report. Check OPENAI_API_KEY."); }
                finally { setReportLoading(false); }
              }}>{reportLoading ? "Generating..." : "Generate Report"}</button>
            </div>
            {report && <div className="report-output">{report}</div>}
          </section>

          <section className="card ai-card">
            <div className="section-head">
              <div><div className="ai-label">✦ AI ANALYST</div><h2>Ask your dataset</h2><p>Ask questions such as “What are the most important patterns?”</p></div>
            </div>
            <div className="ask-row">
              <input value={question} onChange={e=>setQuestion(e.target.value)}
                onKeyDown={e=>e.key==="Enter" && askAI()}
                placeholder="Ask a question about this dataset..." />
              <button className="button" onClick={askAI} disabled={loading}>{loading ? "Thinking..." : "Ask AI"}</button>
            </div>
            {answer && <div className="answer"><strong>AI Analyst</strong><p>{answer}</p></div>}
            <div className="suggestions">
              {["Summarize this dataset", "What patterns should I investigate?", "Which columns need cleaning?"].map(q =>
                <button key={q} onClick={()=>setQuestion(q)}>{q}</button>
              )}
            </div>
          </section>
        </>
      )}

      <footer>Built as a portfolio-ready AI Data Analytics project.</footer>
    </main>
  );
}

function Metric({label,value}) {
  return <div className="metric card"><span>{label}</span><strong>{value}</strong></div>;
}