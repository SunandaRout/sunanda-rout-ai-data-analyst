import "./globals.css";

export const metadata = {
  title: "AI Data Analyst",
  description: "Upload a CSV and explore it with automated analytics and AI insights."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}